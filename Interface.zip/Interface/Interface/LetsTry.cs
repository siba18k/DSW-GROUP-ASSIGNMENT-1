﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interface
{
    public partial class LetsTry : UserControl
    {
        // Declare integer variables to store month and year
        int month, year;
        public LetsTry()
        {
            InitializeComponent();
        }

        private void LetsTry_Load(object sender, EventArgs e)
        {
            // Get the current date and time
            DateTime now = DateTime.Now;

            // Extract the month number from the current date
            month = now.Month;

            // Extract the year from the current date
            year = now.Year;

            // Get the full month name based on the month number
            string monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);

            // Display the month name and year in the label control (likely lbdate)
            lbdate.Text = monthName + " " + year;

            // Create a DateTime object representing the first day of the current month
            DateTime startofthemonth = new DateTime(year, month, 1);

            // Get the total number of days in the current month
            int days = DateTime.DaysInMonth(year, month);

            // Get the day of the week (0-based) for the first day of the month
            int dayoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")) + 1;

            // Loop to add empty controls for days before the actual days of the month
            for (int i = 0; i < dayoftheweek; i++)
            {
                FirstCustomControl userControl = new FirstCustomControl();
                dayContainer.Controls.Add(userControl);
            }

            // Loop to add UserControlDays controls for each day in the month
            for (int i = 0; i < days; i++)
            {
                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                dayContainer.Controls.Add(ucdays);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            // Clear existing controls from the container
            dayContainer.Controls.Clear();

            // Decrement the month number
            month--;
            if (month == 0)
            {
                month = 12;
                year--;
            }

            // Update the label with the new month and year
            string monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            lbdate.Text = monthName + " " + year;

            // Recreate the calendar display for the previous month
            DateTime now = DateTime.Now;
            DateTime startofthemonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int dayoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")) + 1;
            for (int i = 0; i < dayoftheweek; i++)
            {
                FirstCustomControl userControl = new FirstCustomControl();
                dayContainer.Controls.Add(userControl);
            }
            for (int i = 1; i < days; i++)
            {
                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                dayContainer.Controls.Add(ucdays);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            // Clear existing controls from the container
            dayContainer.Controls.Clear();

            // Increment the month number (handles wrapping around to January)
            month++;
            if (month == 13)
            {
                month = 1;
                year++;
            }

            // Update the label with the new month and year
            string monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            lbdate.Text = monthName + " " + year;

            // Recreate the calendar display for the next month
            DateTime now = DateTime.Now;
            DateTime startofthemonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int dayoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d")) + 1;
            for (int i = 0; i < dayoftheweek; i++)
            {
                FirstCustomControl userControl = new FirstCustomControl();
                dayContainer.Controls.Add(userControl);
            }
            for (int i = 1; i < days; i++)
            {
                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                dayContainer.Controls.Add(ucdays);
            }
        }
    }
}
